// Property.cs (Model class)
public class Property
{
    public string? Name { get; set; }
    public string? Address { get; set; }
}
